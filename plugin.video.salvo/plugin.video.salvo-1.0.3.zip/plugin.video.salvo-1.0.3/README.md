# plugin.video.salvo 1.0.1
Kodi unofficial Plugin for WEB TV Salvo5puntozero
