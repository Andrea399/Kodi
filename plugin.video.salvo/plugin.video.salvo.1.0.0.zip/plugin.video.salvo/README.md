plugin.video.salvo
=============

Kodi unofficial plugin for Salvo5.0(tested on Kodi 15.2 Isengard).
