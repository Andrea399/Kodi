# -*- coding: utf-8 -*-
# Module: default
# Author: Andrea Sant.
# Created on: 12.12.2015
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html
#from __future__ import unicode_literals
'''
da fare: diretta che pesca di nuovo, fatto . vedere dopo uscita se esce dal while !!!!
         evitare errore su ultima pagina fatto vedere se funziona
        fare icone piu belle
        salti di pagina in pagina       
        playlist iniziale vedere cosa mettere 
'''
import sys, os, CommonFunctions
import urllib2
from urlparse import parse_qsl
import xbmcgui, xbmc
import xbmcplugin, xbmcaddon

def get_runtime_path():
    return xbmc.translatePath( __settings__.getAddonInfo('Path') )

class MyPlayer(xbmc.Player):

    def __init__(self):
        xbmc.Player.__init__(self)
        
    def cat_link(self):
        li = createListItem(_addonName, thumbnailImage = '{0}/icon.png'.format(os.path.dirname(os.path.abspath(__file__))), streamtype = 'video', infolabels = { 'title' : _addonName })
        ind= 'http://video.mainstreaming.tv/sdk/13/jsRequest.js?contentId=oDgCvza&method=getVideo&skinId=150575&referrer='       
        link= get_link(ind)
        print link
        self.play(link,li)
        
    def onPlayBackEnded( self ):
        # Will be called when xbmc stops playing a file        
        self.cat_link()
        
    def onPlayBackStopped(self):
        global finito        
        finito = True
        

def createListItem(label, label2 = '', iconImage = None, thumbnailImage = None, path = None, fanart = None, streamtype = None, infolabels = None, duration = '', isPlayable = False):
    li = xbmcgui.ListItem(label, label2)
    if iconImage:
      li.setIconImage(iconImage)
    if thumbnailImage:
      li.setThumbnailImage(thumbnailImage)
    if path:
      li.setPath(path)
    if fanart:
      li.setProperty('fanart_image', fanart)
    if streamtype:
      li.setInfo(streamtype, infolabels)
    if streamtype == 'video' and duration:
      li.addStreamInfo(streamtype, {'duration': duration})
    if isPlayable:
      li.setProperty('IsPlayable', 'true')
    return li

_id='plugin.video.salvo'

common = CommonFunctions
common.plugin = "SALVO 5.0 LIVE"
__settings__ = xbmcaddon.Addon(id=_id)
_addonName = xbmcaddon.Addon().getAddonInfo('name')
path = get_runtime_path()
print path
_resdir = path + "/resources"
#add our library to python search path
sys.path.append( _resdir + "/lib/")
sys.path.append( _resdir + "/media/")

print get_runtime_path()
mPath = path+"/resources/media/"



common = CommonFunctions
common.plugin = "SALVO 5.0"

# Get the plugin url in plugin:// notation.
_url = sys.argv[0]
# Get the plugin handle as an integer number.
_handle = int(sys.argv[1])

# Free sample videos are provided by www.vidsplay.com
# Here we use a fixed set of properties simply for demonstrating purposes
# In a "real life" plugin you will need to get info and links to video files/streams
# from some web-site or online service.
VIDEOS = []
MENU = [{'name': 'LIVE',
                    'indirizzo': 'http://video.mainstreaming.tv/sdk/13/jsRequest.js?contentId=oDgCvza&method=getVideo&skinId=150575&referrer=',
                    'thumb': mPath+'live.png',
                    'fanart': mPath+'live.png'
                    },
        {'name': 'Videoteca',
                    'indirizzo': 'http://www.salvo5puntozero.tv/category/videoteca',
                    'thumb': mPath+'icon.png',
                    'fanart': mPath+'icon.png'
                    },
        {'name': 'Trova',
                    'indirizzo': 'http://www.salvo5puntozero.tv',
                    'thumb': mPath + 'search.png',
                    'fanart': mPath+'search.png'
                    },
        {'name': 'English',                      
                    'indirizzo': 'http://www.salvo5puntozero.tv/category/english',
                    'thumb': mPath+'playlist.png',
                    'fanart': mPath+'icon.png'
                    },
        {'name': 'Breaking News',                      
                    'indirizzo': 'http://www.salvo5puntozero.tv/category/videoteca/breakingnews',
                    'thumb': mPath+'',
                    'fanart': mPath+'icon.png'
                    },
        {'name': 'Le puntate serali',                      
                    'indirizzo': 'http://www.salvo5puntozero.tv/category/videoteca/puntate-serali',
                    'thumb': mPath+'',
                    'fanart': mPath+'icon.png'
                    },
        {'name': 'Le Interviste di Salvo5puntozero',                      
                    'indirizzo': 'http://www.salvo5puntozero.tv/category/videoteca/intervistedisalvo5puntozero',
                    'thumb': mPath+'',
                    'fanart': mPath+'icon.png'
                    },                     
        {'name': 'Miscappaladiretta',                      
                    'indirizzo': 'http://www.salvo5puntozero.tv/category/videoteca/miscappaladiretta',
                    'thumb': mPath+'icon.png',
                    'fanart': mPath+'icon.png'
                    },
        {'name': 'Le interviste a Salvo',                      
                    'indirizzo': 'http://www.salvo5puntozero.tv/category/videoteca/interviste-a-salvo',
                    'thumb': mPath+'',
                    'fanart': mPath+'icon.png'
                    },
        {'name': 'Alla Conquista di se stessi di Silvano Agosti',                      
                    'indirizzo': 'http://www.salvo5puntozero.tv/category/videoteca/alla-conquista-di-se-stessi',
                    'thumb': mPath+'',
                    'fanart': mPath+'icon.png'
                    },
        {'name': 'Diego Fusaro. Ciò che esiste non è tutto',                      
                    'indirizzo': 'http://www.salvo5puntozero.tv/category/diego-fusaro-cio-che-esiste-non-e-tutto',
                    'thumb': mPath+'',
                    'fanart': mPath+'icon.png'
                    },
        {'name': "Cos'è il denaro di Daniele Pace",                      
                    'indirizzo': 'http://www.salvo5puntozero.tv/category/gli-spazi-autogestiti-su-salvo5puntozero/cose-il-denaro',
                    'thumb': mPath+'',
                    'fanart': mPath+'icon.png'
                    },
        {'name': 'Il valore della moneta di Davide Storelli',                      
                    'indirizzo': 'http://www.salvo5puntozero.tv/category/gli-spazi-autogestiti-su-salvo5puntozero/il-valore-della-moneta-di-davide-storelli',
                    'thumb': mPath+'',
                    'fanart': mPath+'icon.png'
                    },
        {'name': 'Sbanchiamo di Rossella Fidanza',                      
                    'indirizzo': 'http://www.salvo5puntozero.tv/category/gli-spazi-autogestiti-su-salvo5puntozero/sbanchiamo-di-rossella-fidanza',
                    'thumb': mPath+'',
                    'fanart': mPath+'icon.png'
                    },
        {'name': 'What money is by Daniele Pace',                      
                    'indirizzo': 'http://www.salvo5puntozero.tv/category/gli-spazi-autogestiti-su-salvo5puntozero/what-money-is-by-daniele-pace',
                    'thumb': mPath+'',
                    'fanart': mPath+'icon.png'
                    },
        {'name': 'Partners',                      
                    'indirizzo': 'http://www.salvo5puntozero.tv/category/videoteca/partners',
                    'thumb': mPath+'',
                    'fanart': mPath+'icon.png'
                    }        
        ]

def ricerca(category):
    kb =xbmc.Keyboard ('', 'Ricerca', False)
    kb.doModal()
    
    if (kb.isConfirmed()):
        richiesta = kb.getText()
        richiesta = richiesta.strip()
        stringa = '?s='+ richiesta.replace(" ", "+")  
    return stringa
    
def get_link1(ind):
    req = urllib2.Request(ind,headers={ 'User-Agent': 'Mozilla/5.0 (iPhone; U; CPU iPhone OS 3_0 like Mac OS X; en-us) AppleWebKit/528.18 (KHTML, like Gecko) Version/4.0 Mobile/7A341 Safari/528.16'})
    response = urllib2.urlopen(req)
    the_page = response.read()
    page = common.parseDOM(the_page, "div",attrs = {"class":"screen fluid-width-video-wrapper"})    
    link1 = common.parseDOM(page, "iframe", ret = "src")
    print link1
    start = link1[0].find("embed")+ 6
    stop = link1[0].find("?auto")
    cod = link1[0][start:stop]
    link = "http://video.mainstreaming.tv/sdk/13/jsRequest.js?contentId="+cod+"&method=getVideo&skinId=150575&referrer="
    print link
    
    return link
  
def get_link(ind):
    req = urllib2.Request(ind,headers={ 'User-Agent': 'Mozilla/5.0 (iPhone; U; CPU iPhone OS 3_0 like Mac OS X; en-us) AppleWebKit/528.18 (KHTML, like Gecko) Version/4.0 Mobile/7A341 Safari/528.16'})
    response = urllib2.urlopen(req)
    the_page = response.read()
    print the_page
    linkStart =the_page.find('attributesHtml5.href="')+22
    linkStop = the_page.find('m3u8')+4
    ind = the_page[linkStart:linkStop]
    print ind
    return ind  




def get_videos(category, page, cerca):
    """
    Get the list of videofiles/streams.
    Here you can insert some parsing code that retrieves
    the list of videostreams in a given category from some site or server.
    :param category: str
    :return: list
    """
    global VIDEOS    
    ind = MENU[category]['indirizzo']+'/page/'+ str(page)+ cerca    
    req = urllib2.Request(ind,headers={ 'User-Agent': 'Mozilla/5.0 (iPhone; U; CPU iPhone OS 3_0 like Mac OS X; en-us) AppleWebKit/528.18 (KHTML, like Gecko) Version/4.0 Mobile/7A341 Safari/528.16'})
    response = urllib2.urlopen(req)
    the_page = response.read()
    page = common.parseDOM(the_page, "div",attrs = {"class":"nag cf"})
    video = common.parseDOM(page, "a", attrs = {"class":"clip-link"}, ret = "href")    
    name = (common.parseDOM(page, "a" ,attrs = {"class":"clip-link"}, ret = "title"))
    thumb = common.parseDOM(page, "img", ret = "src")
    
    VIDEOS = []   
    i = 0
    while i < len(video):
        
        VIDEOS.append({'video': video[i],
                    'name': name[i].encode('utf-8'),
                    'thumb': thumb[i]})
        i = i + 1    
    return #VIDEOS


def list_categories():
    """
    Create the list of video categories in the Kodi interface.
    :return: None
    """    
    listing = []
    # Iterate through categories    
    for index in range(len(MENU)):
        # Create a list item with a text label and a thumbnail image.
        list_item = xbmcgui.ListItem(label=MENU[index]['name'],thumbnailImage=MENU[index]['thumb'])        
        list_item.setProperty('fanart_image', MENU[index]['fanart'])        
        url = '{0}?action=listing&category={1}&page=1&stringa={2}'.format(_url, index, " ")
        is_folder = True        
        listing.append((url, list_item, is_folder))  
    xbmcplugin.addDirectoryItems(_handle, listing, len(listing))
    xbmcplugin.addSortMethod(_handle, xbmcplugin.SORT_METHOD_UNSORTED) # non ordina, lascia cosi 
    # Finish creating a virtual folder.
    xbmcplugin.endOfDirectory(_handle)
    return


def list_videos(category, page, cerca):
    """
    Create the list of playable videos in the Kodi interface.
    :param category: str
    :return: None
    """
    global VIDEOS    
    cerca = cerca.replace('_','+')
    if category == 0:
        Live = MyPlayer()
        Live.cat_link()        
        while(not finito):
            xbmc.sleep(500)            
        print "fine Live"        
        del Live
        return        
    if (category == 2 and page==1 and (cerca.strip()=="")):
        cerca= ricerca(category)
    try:
        get_videos(category,page,cerca)
    except:
        return
    # Create a list for our items.
    print VIDEOS
    listing = []
    # Iterate through videos.
    for index in range(len(VIDEOS)):   
        list_item = xbmcgui.ListItem(label=VIDEOS[index]['name'], thumbnailImage=VIDEOS[index]['thumb'])
        # Set a fanart image for the list item.
        # Here we use the same image as the thumbnail for simplicity's sake.
        list_item.setProperty('fanart_image', VIDEOS[index]['thumb'])
        # Set additional info for the list item.
        list_item.setInfo('video', {'title': VIDEOS[index]['name']})
        # Set additional graphics (banner, poster, landscape etc.) for the list item.
        # Again, here we use the same image as the thumbnail for simplicity's sake.
        list_item.setArt({'landscape': VIDEOS[index]['thumb']})
        # Set 'IsPlayable' property to 'true'.
        # This is mandatory for playable items!
        list_item.setProperty('IsPlayable', 'true')
        # Create a URL for the plugin recursive callback.
        # Example: plugin://plugin.video.example/?action=play&video=http://www.vidsplay.com/vids/crab.mp4
        #url = '{0}?action=play&video={1}'.format(_url, get_link(get_link1(VIDEOS[index]['video'])))
        url = '{0}?action=play&video={1}'.format(_url, VIDEOS[index]['video'])      
        is_folder = False 
        # Add our item to the listing as a 3-element tuple.
        listing.append((url, list_item, is_folder))
    is_folder = True    
    list_item = xbmcgui.ListItem(label='Pagina Successiva ({0})'.format(str(page+1)), thumbnailImage=mPath+'next.png')    
    list_item.setProperty('fanart_image', mPath+'icon.png')
    url = '{0}?action=listing&category={1}&page={2}&stringa={3}'.format(_url,category,str(page+1),cerca.replace("+","_"))
    listing.append((url, list_item, is_folder))
    xbmcplugin.addDirectoryItems(_handle, listing, len(listing))
    xbmcplugin.endOfDirectory(_handle)
    return

def play_video(path):
    """
    Play a video by the provided path.
    :param path: str
    :return: None
    """
    rpath = get_link1(path)   
    npath =get_link(rpath)    
    play_item = xbmcgui.ListItem(path=npath)
    xbmcplugin.setResolvedUrl(_handle, True, listitem=play_item)
    return

def router(paramstring):
    """
    Router function that calls other functions
    depending on the provided paramstring
    :param paramstring:
    :return:
    """
    global VIDEOS    
    params = dict(parse_qsl(paramstring))
    print params    
    # Check the parameters passed to the plugin
    if params:
        if params['action'] == 'listing':
            # Display the list of videos in a provided category.            
            list_videos(int(params['category']),int(params['page']),params['stringa'])
        elif params['action'] == 'play':
            # Play a video from a provided URL
            play_video(params['video'])
    else:
        # If the plugin is called from Kodi UI without any parameters,
        # display the list of video categories
        list_categories()
        
if __name__ == '__main__':
    # Call the router function and pass the plugin call parameters to it.
    # We use string slicing to trim the leading '?' from the plugin call paramstring   
    print sys.argv[0]
    print sys.argv[1]
    print sys.argv[2][1:]
    finito = False
    router(sys.argv[2][1:])
